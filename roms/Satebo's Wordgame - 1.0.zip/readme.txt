Satebo's Wordgame (v1.0)

Satebo's Wordgame is a homebrew game for the Satellaview,
the Super Famicom extension.
It is an implementation of Wordle, a game developped
by Josh Wardle, that became popular in 2021 before being
bought by the New York Times.

The game is named after Satebo, one of the two
Satellaview mascots.

########## Emulation ##########

The game works on:
- snes9x-1.61
- bsnes-plus

Requirement: [BS-X BIOS (English) - No DRM - 2016 v1.3]
(https://project.satellaview.org/downloads.htm)
Make sure to turn on the option "Get BS-X date and time from local time"

########## Credits ##########
Game made by Krokodyl
More info: https://github.com/Krokodyl/satebos-wordgame